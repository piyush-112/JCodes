package com.validation;

public class CricketException extends Exception {

	
	private static final long serialVersionUID = 7032107611880722942L;

	public CricketException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
