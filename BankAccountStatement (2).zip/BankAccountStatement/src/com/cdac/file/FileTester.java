package com.cdac.file;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FileTester {
	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in);
				BufferedReader in = new BufferedReader(new FileReader("customer.txt"))) {
			List<String[]> list = new ArrayList<>();
			String s = in.readLine();
			while (s != null) {
				String[] str = s.split(",");
				list.add(str);
				s = in.readLine();
			}
			list.remove(0);
			double sum = list.stream().mapToDouble(v -> Double.parseDouble(v[3])).sum();
			System.out.println("Sum : " + sum);
			double max = list.stream().mapToDouble(v -> Double.parseDouble(v[3])).max().orElseThrow();
			System.out.println("Maximum : " + max);
			double sumShopping = list.stream().filter(v -> v[1].equals("Shopping"))
					.mapToDouble(v -> Double.parseDouble(v[2])).sum();
			System.out.println("Shopping Expense :" + sumShopping);
			list.stream().filter(l -> ((Double) Double.parseDouble(l[2])).equals(list.stream().mapToDouble(v -> Double.parseDouble(v[2])).max().orElseThrow()))
					.forEach(v -> System.out.println("Date :" + v[0]));
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}
}
