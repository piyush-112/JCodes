package com.validations;

import java.util.Map;

import com.Pen.Pen;
import com.customException.PenException;

public class PenValidations {

	public static Pen findByPenId(Map<Integer, Pen> myMap, int penId) throws PenException {

		if (!(myMap.containsKey(penId)))
			throw new PenException("Pen ID not found!");

		return myMap.get(penId);
	}

}
