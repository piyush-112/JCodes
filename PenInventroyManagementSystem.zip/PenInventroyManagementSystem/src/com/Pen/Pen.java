package com.Pen;

import java.time.LocalDate;

public class Pen {

	private static int counter = 1;
	private int penId;
	private Brand brand;
	private String color;
	private String inkColor;
	private Material material;
	private int stock;
	private LocalDate stockListingDate;
	private LocalDate stockUpdateDate;
	private double price;
	private double discount;

	public Pen(Brand brand, String color, String inkColor, Material material, int stock, LocalDate stockListingDate,
			double price, double discount) {
		this.penId = counter++;
		this.brand = brand;
		this.color = color;
		this.inkColor = inkColor;
		this.material = material;
		this.stock = stock;
		this.stockListingDate = stockListingDate;
		this.price = price;
		this.discount = discount;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public LocalDate getStockUpdateDate() {
		return stockUpdateDate;
	}

	public void setStockUpdateDate(LocalDate stockUpdateDate) {
		this.stockUpdateDate = stockUpdateDate;
	}

	public void setBrand(Brand brand) {
		this.brand = brand;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public void setInkColor(String inkColor) {
		this.inkColor = inkColor;
	}

	public void setMaterial(Material material) {
		this.material = material;
	}

	public LocalDate getStockListingDate() {
		return stockListingDate;
	}

	public void setStockListingDate(LocalDate stockListingDate) {
		this.stockListingDate = stockListingDate;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public int getPenId() {
		return penId;
	}



	@Override
	public String toString() {
		return "[ Pen Id: " + penId + ", Brand=" + brand + ", color=" + color + ", inkColor=" + inkColor + ", material="
				+ material + ", stock=" + stock + ", stockListingDate=" + stockListingDate + ", price=" + price
				+ ", Discount: " + discount + "]";
	}

}
