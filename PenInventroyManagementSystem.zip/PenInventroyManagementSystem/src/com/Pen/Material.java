package com.Pen;

public enum Material {
	
	PLASTIC,ALLOYSTEEL,METAL,LAAKDI

}
