package com.utils;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import com.Pen.Brand;
import com.Pen.Material;
import com.Pen.Pen;

public class PopulateData {

	public static Map<Integer, Pen> populateMap() {
		Map<Integer, Pen> myMap = new HashMap<>();

		myMap.put(1, new Pen(Brand.CELLO, "Pink", "Blue", Material.LAAKDI, 10, LocalDate.parse("2023-05-10"), 5.75,10));
		myMap.put(2, new Pen(Brand.PARKER, "Red", "Black", Material.PLASTIC, 20, LocalDate.parse("2022-07-20"), 10.90,9));
		myMap.put(3, new Pen(Brand.RENAULDS, "Black", "Red", Material.METAL, 30, LocalDate.parse("2021-11-19"), 7.25,20));
		myMap.put(4, new Pen(Brand.SHAI_PEN, "Yellow", "Green", Material.ALLOYSTEEL, 5, LocalDate.parse("2023-05-07"),
				6.15,15));
		myMap.put(5, new Pen(Brand.CELLO, "Gray", "Blue", Material.LAAKDI, 10, LocalDate.parse("2024-04-21"), 10,12.75));

		return myMap;
	}

}
