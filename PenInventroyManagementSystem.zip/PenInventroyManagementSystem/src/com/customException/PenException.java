package com.customException;

public class PenException extends Exception{


	private static final long serialVersionUID = -1768107075900191561L;

	public PenException(String message) {
		super(message);
	}
	
	

}
