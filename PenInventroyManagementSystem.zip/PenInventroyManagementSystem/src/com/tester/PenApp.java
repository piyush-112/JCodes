package com.tester;

import java.time.LocalDate;
import java.util.Map;
import java.util.Scanner;

import com.Pen.Brand;
import com.Pen.Material;
import com.Pen.Pen;
import com.utils.PopulateData;
import com.validations.PenValidations;

public class PenApp {

	public static void main(String[] args) {

		try (Scanner sc = new Scanner(System.in)) {
			boolean exit = false;
			String ch;
			Map<Integer, Pen> myMap = PopulateData.populateMap();

			while (!exit) {
				System.out.println("\n\tMenu");
				System.out.println("1.Add new pen");
				System.out.println("2.Update pen details");
				System.out.println("3.Set discount");
				System.out.println("4.Remove pens");
				System.out.println("5.Display all data");
				System.out.println("0.EXIT");
				System.out.print("Enter your choice: ");
				ch = sc.next();
				try {

					switch (ch) {

					case "1":
						System.out.print("Select brand [CELLO,PARKER,RENAULDS,SHAI_PEN]: ");
						Brand brand = Brand.valueOf(sc.next().toUpperCase());

						System.out.print("Enter color: ");
						String color = sc.next();

						System.out.print("Enter ink color: ");
						String inkColor = sc.next();

						System.out.print("Select Material [PLASTIC,ALLOYSTEEL,METAL]: ");
						Material material = Material.valueOf(sc.next().toUpperCase());

						System.out.print("Enter number of stock: ");
						int stock = sc.nextInt();

						System.out.print("Enter listing date [yyyy-MM-dd]: ");
						LocalDate date = LocalDate.parse(sc.next());

						System.out.print("Enter price per piece: ");
						double amount = sc.nextDouble();

						System.out.print("Enter discount: ");
						double discount = sc.nextDouble();

						Pen p1 = new Pen(brand, color, inkColor, material, stock, date, amount, discount);

						myMap.put(p1.getPenId(), p1);
						System.out.println("Pen added successfully!");

						break;

					case "2":
						System.out.print("Enter pen id: ");
						int pid = sc.nextInt();

						p1 = PenValidations.findByPenId(myMap, pid);
						System.out.print("Select brand [CELLO,PARKER,RENAULDS,SHAI_PEN]: ");
						brand = Brand.valueOf(sc.next().toUpperCase());
						p1.setBrand(brand);

						System.out.print("Enter color: ");
						color = sc.next();
						p1.setColor(color);

						System.out.print("Enter ink color: ");
						inkColor = sc.next();
						p1.setInkColor(inkColor);

						System.out.print("Select Material [PLASTIC,ALLOYSTEEL,METAL]: ");
						material = Material.valueOf(sc.next().toUpperCase());
						p1.setMaterial(material);

						System.out.print("Enter number of stock: ");
						stock = sc.nextInt();
						p1.setStock(stock);

						p1.setStockUpdateDate(LocalDate.now());

						System.out.println("Pen details updated successfully!");
						break;

					case "3":

						myMap.values().stream()
								.filter(s -> s.getStockListingDate().isBefore(LocalDate.now().minusMonths(3)))
								.forEach(s -> s.setDiscount(s.getDiscount() + 20));

						System.out.println("20% Discount added Successfully..!!!");
						break;

					case "4":
						myMap.values().removeIf(s -> s.getStockListingDate().isBefore(LocalDate.now().minusMonths(9)));

						System.out.println("9 Months Old Pens are Removed Successfully...!!!");
						break;

					case "5":
						myMap.values().stream().forEach(s -> System.out.println(s));
						break;
					case "0":
						System.out.println("Exting application!");
						exit = true;
						break;
					default:
						System.out.println("Invalid choice!");
						break;
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

}
