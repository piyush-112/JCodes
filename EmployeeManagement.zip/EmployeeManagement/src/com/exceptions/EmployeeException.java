package com.exceptions;

public class EmployeeException extends Exception
{

	private static final long serialVersionUID = 8544945836127285957L;

	public EmployeeException(String message) {
		super(message);
		
	}



}
