package com.utils;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import com.tasks.Task;

public class PopulateData {

//	public Task(int id, String taskName, String desc, LocalDate taskDate, String status, boolean isActive) {
	
	public static Map<Integer, Task> populateData()
	{
		HashMap<Integer, Task> myMap = new HashMap<>();
		
		myMap.put(1,new Task("Social Media","Social madia handling",LocalDate.parse("2024-02-02")));
		myMap.put(2,new Task("Coding","Practising codes",LocalDate.parse("2023-02-02")));
		myMap.put(3,new Task("Eating","Eating food",LocalDate.parse("2024-01-02")));
		myMap.put(4,new Task("Gym","go to Gym",LocalDate.parse("2024-04-25")));
		
		
		return myMap;
	}
}
