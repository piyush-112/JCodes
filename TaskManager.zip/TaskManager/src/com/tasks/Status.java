package com.tasks;

public enum Status {
	PENDING, IN_PROGRESS, COMPLETED;

}


