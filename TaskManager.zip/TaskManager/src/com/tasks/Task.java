package com.tasks;

import java.time.LocalDate;

public class Task {

	private static int counter = 1;
	private int id;
	private String taskName;
	private String desc;
	private LocalDate taskDate;
	private Status status;
	private boolean isActive;

	public Task(String taskName, String desc, LocalDate taskDate) {
		super();
		this.id = counter;
		this.taskName = taskName;
		this.desc = desc;
		this.taskDate = taskDate;
		this.status = Status.PENDING;
		this.isActive = true;
		counter++;
	}

	@Override
	public String toString() {
		return "Task [id=" + id + ", taskName=" + taskName + ", desc=" + desc + ", taskDate=" + taskDate + ", status="
				+ status + ", isActive=" + isActive + "]";
	}

	public static int getCounter() {
		return counter;
	}

	public int getId() {
		return id;
	}

	public String getTaskName() {
		return taskName;
	}

	public String getDesc() {
		return desc;
	}

	public LocalDate getTaskDate() {
		return taskDate;
	}

	public Status getStatus() {
		return status;
	}
	
	public void setStatus(Status status) {
			this.status = status;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	
	

}
