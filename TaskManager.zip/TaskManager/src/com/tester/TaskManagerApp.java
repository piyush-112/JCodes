package com.tester;

import java.time.LocalDate;
import java.util.Map;
import java.util.Scanner;

import com.tasks.Status;
import com.tasks.Task;
import com.utils.PopulateData;

public class TaskManagerApp {
	public static void main(String[] args) {

		try (Scanner sc = new Scanner(System.in)) {
			boolean exit = false;
			String ch;
//			public Task(int id, String taskName, String desc, LocalDate taskDate, String status) 
			Map<Integer, Task> myTasks = PopulateData.populateData();
			while (!exit) {
				try {
					System.out.println("\n\tMenu");
					System.out.println("1.Add New Task");
					System.out.println("2.Delete a Task");
					System.out.println("3.Update Task Status");
					System.out.println("4.Display All pending tasks");
					System.out.println("5.Display all pending tasks for today");
					System.out.println("6.Display all tasks sorted by taskDate");
					System.out.println("7.Display all tasks ");
					System.out.println("0.Exit");
					System.out.print("Enter your Choice : ");
					ch = sc.next();
					switch (ch) {
					case "1":
						System.out.println("Enter Task Name: ");
						String task = sc.next();
						System.out.println("Enter Task Description: ");
						String taskDesc = sc.next();
						System.out.println("Enter Task Date: ");
						LocalDate taskDate = LocalDate.parse(sc.next());
						
	

						Task T = new Task(task, taskDesc, taskDate);

						myTasks.put(T.getId(), T);
						System.out.println("Task Added Succesfully");
						break;

					case "2":
						System.out.println("Enter Task ID: ");
						// delete a task

						int id = sc.nextInt();

						myTasks.values().removeIf(s -> s.getId() == id);
						myTasks.values().stream().forEach(v->v.setActive(false));
						System.out.println("Task deleted successfully!");

						break;

					case "3":
						// update task status

						System.out.print("Enter task id: ");
						id = sc.nextInt();
						System.out.print("Enter Task Status[PENDING, IN_PROGRESS, COMPLETED]: ");
						Status status = Status.valueOf(sc.next().toUpperCase());

						myTasks.values().stream().filter(s->s.getId()==id).forEach(s -> s.setStatus(status));

						System.out.println("Status updated successfully!");

						break;
					case "4":
						// display all pending details
						
							
						myTasks.values().stream().filter(s -> s.getStatus()==Status.PENDING).
						forEach(s->System.out.println(s));
						
						
						break;
					case "5":
						// display all pending details of today
						
						
						myTasks.values().stream().filter(s -> (s.getStatus()==Status.PENDING)&&s.getTaskDate().equals(LocalDate.now())).
						forEach(s->System.out.println(s));
						
						
						break;
						
					case "6":
						
						myTasks.values().stream().
						sorted((s1,s2)->s1.getTaskDate().compareTo(s2.getTaskDate())).forEach(s->System.out.println(s));
						break;
						
					case "7":
						myTasks.values().stream().forEach(s->System.out.println(s));
						break;
					case "0":
						System.out.println("Exiting Application...");
						exit = true;
						break;
					default:
						System.out.println("Enter valid Choice..");
						break;
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
}
