package com.exception;

public class StockException extends Exception 
{

	private static final long serialVersionUID = 3155374776678374389L;

	public StockException(String message)
	{
		super(message);
	}
}
